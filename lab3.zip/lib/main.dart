import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Меню ресторана',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange),
        useMaterial3: true,
      ),
      home: const CategoriesScreen(),
    );
  }
}

// ----- Модели данных -----
class Dish {
  final String name;
  final String description;
  final double price;
  final String emoji;
  final List<String> ingredients;

  const Dish({
    required this.name,
    required this.description,
    required this.price,
    required this.emoji,
    required this.ingredients,
  });
}

class Category {
  final String name;
  final String emoji;
  final Color color;
  final List<Dish> dishes;

  const Category({
    required this.name,
    required this.emoji,
    required this.color,
    required this.dishes,
  });
}

// ----- Глобальные данные меню -----
final List<Category> menuData = [
  const Category(
    name: 'Закуски',
    emoji: '🍢',
    color: Colors.green,
    dishes: [
      Dish(
        name: 'Брускетта с томатами',
        description: 'Хрустящий хлеб с помидорами, чесноком и базиликом',
        price: 320,
        emoji: '🍅',
        ingredients: [
          'Хлеб',
          'Помидоры',
          'Чеснок',
          'Базилик',
          'Оливковое масло'
        ],
      ),
      Dish(
        name: 'Сырная тарелка',
        description: 'Ассорти из трёх сортов сыра с мёдом и орехами',
        price: 450,
        emoji: '🧀',
        ingredients: [
          'Пармезан',
          'Камамбер',
          'Голубой сыр',
          'Мёд',
          'Грецкие орехи'
        ],
      ),
      Dish(
        name: 'Карпаччо из говядины',
        description: 'Тонкие ломтики говядины с пармезаном и рукколой',
        price: 520,
        emoji: '🥩',
        ingredients: [
          'Говядина',
          'Пармезан',
          'Руккола',
          'Лимонный сок',
          'Оливковое масло'
        ],
      ),
    ],
  ),
  const Category(
    name: 'Супы',
    emoji: '🥣',
    color: Colors.orange,
    dishes: [
      Dish(
        name: 'Томатный суп',
        description: 'Густой суп из томатов с базиликом и сливками',
        price: 280,
        emoji: '🍅',
        ingredients: ['Помидоры', 'Лук', 'Чеснок', 'Сливки', 'Базилик'],
      ),
      Dish(
        name: 'Грибной крем-суп',
        description: 'Нежный суп из лесных грибов',
        price: 310,
        emoji: '🍄',
        ingredients: ['Шампиньоны', 'Лук', 'Сливки', 'Картофель', 'Зелень'],
      ),
      Dish(
        name: 'Солянка мясная',
        description: 'Наваристый суп с тремя видами мяса и лимоном',
        price: 380,
        emoji: '🥘',
        ingredients: [
          'Говядина',
          'Колбаса',
          'Ветчина',
          'Оливки',
          'Лимон',
          'Сметана'
        ],
      ),
    ],
  ),
  const Category(
    name: 'Основные блюда',
    emoji: '🍽️',
    color: Colors.red,
    dishes: [
      Dish(
        name: 'Стейк из говядины',
        description:
            'Мраморная говядина, прожарка medium, с картофелем и соусом',
        price: 890,
        emoji: '🥩',
        ingredients: [
          'Говядина',
          'Картофель',
          'Сливочное масло',
          'Розмарин',
          'Соус демиглас'
        ],
      ),
      Dish(
        name: 'Лосось на гриле',
        description: 'Филе лосося с овощами гриль и лимонным соусом',
        price: 750,
        emoji: '🐟',
        ingredients: ['Лосось', 'Цукини', 'Баклажан', 'Перец', 'Лимонный соус'],
      ),
      Dish(
        name: 'Паста Карбонара',
        description: 'Спагетти с беконом, яйцом и пармезаном',
        price: 490,
        emoji: '🍝',
        ingredients: ['Спагетти', 'Бекон', 'Яйца', 'Пармезан', 'Черный перец'],
      ),
    ],
  ),
];

// ----- Глобальная корзина (задание 2) -----
// Каждый элемент: { 'dish': Dish, 'quantity': int }
List<Map<String, dynamic>> cart = [];

// ----- Экран категорий с поиском (задание 3) -----
class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchText = '';

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      setState(() {
        _searchText = _searchController.text;
      });
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // Получаем отфильтрованный список блюд (если поиск активен)
  List<Dish> get filteredDishes {
    if (_searchText.isEmpty) return [];
    return menuData
        .expand((cat) => cat.dishes)
        .where((dish) =>
            dish.name.toLowerCase().contains(_searchText.toLowerCase()))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Меню'),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const CartScreen()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Поле поиска
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Поиск блюд...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          // Основное содержимое
          Expanded(
            child: _searchText.isEmpty
                ? _buildCategoriesList()
                : _buildSearchResults(),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoriesList() {
    return ListView.builder(
      itemCount: menuData.length,
      itemBuilder: (context, index) {
        final category = menuData[index];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: category.color,
              child: Text(
                category.emoji,
                style: const TextStyle(fontSize: 24),
              ),
            ),
            title: Text(
              category.name,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DishesScreen(category: category),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildSearchResults() {
    final dishes = filteredDishes;
    if (dishes.isEmpty) {
      return const Center(child: Text('Ничего не найдено'));
    }
    return ListView.builder(
      itemCount: dishes.length,
      itemBuilder: (context, index) {
        final dish = dishes[index];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: ListTile(
            leading: Text(dish.emoji, style: const TextStyle(fontSize: 32)),
            title: Text(dish.name),
            subtitle: Text('${dish.price} ₽'),
            trailing: IconButton(
              icon: const Icon(Icons.add_shopping_cart),
              onPressed: () => _addToCart(dish),
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DishDetailScreen(dish: dish),
                ),
              );
            },
          ),
        );
      },
    );
  }

  void _addToCart(Dish dish) {
    setState(() {
      int index = cart.indexWhere((item) => item['dish'] == dish);
      if (index != -1) {
        cart[index]['quantity'] = cart[index]['quantity'] + 1;
      } else {
        cart.add({'dish': dish, 'quantity': 1});
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${dish.name} добавлено в корзину')),
    );
  }
}

// ----- Экран блюд в категории -----
class DishesScreen extends StatelessWidget {
  final Category category;

  const DishesScreen({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${category.emoji} ${category.name}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const CartScreen()),
              );
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: category.dishes.length,
        itemBuilder: (context, index) {
          final dish = category.dishes[index];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(
              leading: Text(dish.emoji, style: const TextStyle(fontSize: 40)),
              title: Text(dish.name),
              subtitle: Text('${dish.price} ₽'),
              trailing: IconButton(
                icon: const Icon(Icons.add_shopping_cart),
                onPressed: () => _addToCart(context, dish),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DishDetailScreen(dish: dish),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  void _addToCart(BuildContext context, Dish dish) {
    int index = cart.indexWhere((item) => item['dish'] == dish);
    if (index != -1) {
      cart[index]['quantity'] = cart[index]['quantity'] + 1;
    } else {
      cart.add({'dish': dish, 'quantity': 1});
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${dish.name} добавлено в корзину')),
    );
  }
}

// ----- Экран деталей блюда -----
class DishDetailScreen extends StatelessWidget {
  final Dish dish;

  const DishDetailScreen({super.key, required this.dish});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(dish.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const CartScreen()),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Text(
                dish.emoji,
                style: const TextStyle(fontSize: 80),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              dish.name,
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              '${dish.price} ₽',
              style: const TextStyle(fontSize: 20, color: Colors.green),
            ),
            const SizedBox(height: 16),
            const Text(
              'Описание:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Text(dish.description, style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 16),
            const Text(
              'Ингредиенты:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Wrap(
              spacing: 8,
              children: dish.ingredients
                  .map((ing) => Chip(label: Text(ing)))
                  .toList(),
            ),
            const SizedBox(height: 24),
            Center(
              child: ElevatedButton.icon(
                onPressed: () => _addToCart(context),
                icon: const Icon(Icons.add_shopping_cart),
                label: const Text('В заказ'),
                style: ElevatedButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  textStyle: const TextStyle(fontSize: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _addToCart(BuildContext context) {
    int index = cart.indexWhere((item) => item['dish'] == dish);
    if (index != -1) {
      cart[index]['quantity'] = cart[index]['quantity'] + 1;
    } else {
      cart.add({'dish': dish, 'quantity': 1});
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${dish.name} добавлено в корзину')),
    );
  }
}

// ----- Экран корзины (задание 2) -----
class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Корзина'),
      ),
      body: cart.isEmpty
          ? const Center(child: Text('Корзина пуста'))
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: cart.length,
                    itemBuilder: (context, index) {
                      final item = cart[index];
                      final dish = item['dish'] as Dish;
                      final quantity = item['quantity'] as int;
                      return Card(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 4),
                        child: ListTile(
                          leading: Text(dish.emoji,
                              style: const TextStyle(fontSize: 32)),
                          title: Text(dish.name),
                          subtitle: Text('${dish.price} ₽ × $quantity'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.remove),
                                onPressed: () {
                                  setState(() {
                                    if (quantity == 1) {
                                      cart.removeAt(index);
                                    } else {
                                      cart[index]['quantity'] = quantity - 1;
                                    }
                                  });
                                },
                              ),
                              Text('$quantity'),
                              IconButton(
                                icon: const Icon(Icons.add),
                                onPressed: () {
                                  setState(() {
                                    cart[index]['quantity'] = quantity + 1;
                                  });
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                _buildTotal(context),
              ],
            ),
    );
  }

  Widget _buildTotal(BuildContext context) {
    double total = 0;
    for (var item in cart) {
      final dish = item['dish'] as Dish;
      final quantity = item['quantity'] as int;
      total += dish.price * quantity;
    }
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primaryContainer,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Итого:',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          Text(
            '${total.toStringAsFixed(2)} ₽',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
