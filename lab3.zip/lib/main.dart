import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// ==================== МОДЕЛИ ДАННЫХ ====================

class Dish {
  final String name;
  final String description;
  final double price;
  final String emoji;
  final List<String> ingredients;

  Dish({
    required this.name,
    required this.description,
    required this.price,
    required this.emoji,
    required this.ingredients,
  });
}

class Category {
  final String name;
  final String emoji;
  final Color color;
  final List<Dish> dishes;

  Category({
    required this.name,
    required this.emoji,
    required this.color,
    required this.dishes,
  });
}

// ==================== ДАННЫЕ МЕНЮ ====================

final List<Category> menuData = [
  Category(
    name: 'Закуски',
    emoji: '🍢',
    color: Colors.orangeAccent,
    dishes: [
      Dish(
        name: 'Брускетта',
        description: 'Хрустящий багет с томатами, чесноком и базиликом',
        price: 250,
        emoji: '🥖',
        ingredients: [
          'багет',
          'помидоры',
          'чеснок',
          'базилик',
          'оливковое масло'
        ],
      ),
      Dish(
        name: 'Сырная тарелка',
        description: 'Три вида сыра с медом и орехами',
        price: 450,
        emoji: '🧀',
        ingredients: [
          'пармезан',
          'горгонзола',
          'камамбер',
          'мед',
          'грецкие орехи'
        ],
      ),
    ],
  ),
  Category(
    name: 'Супы',
    emoji: '🥣',
    color: Colors.lightBlueAccent,
    dishes: [
      Dish(
        name: 'Томатный суп',
        description: 'Классический суп из спелых томатов с базиликом',
        price: 320,
        emoji: '🍅',
        ingredients: ['томаты', 'лук', 'чеснок', 'базилик', 'сливки'],
      ),
      Dish(
        name: 'Грибной крем-суп',
        description: 'Нежный суп из лесных грибов с трюфельным маслом',
        price: 380,
        emoji: '🍄',
        ingredients: [
          'шампиньоны',
          'белые грибы',
          'лук',
          'сливки',
          'трюфельное масло'
        ],
      ),
    ],
  ),
  // Новая категория "Основные блюда" (задание 1)
  Category(
    name: 'Основные блюда',
    emoji: '🍽️',
    color: Colors.deepPurpleAccent,
    dishes: [
      Dish(
        name: 'Стейк из говядины',
        description: 'Мраморная говядина, прожарка medium rare, соус демиглас',
        price: 890,
        emoji: '🥩',
        ingredients: ['говядина', 'соль', 'перец', 'розмарин', 'соус демиглас'],
      ),
      Dish(
        name: 'Паста Карбонара',
        description: 'Спагетти с беконом, пармезаном и яйцом',
        price: 490,
        emoji: '🍝',
        ingredients: ['спагетти', 'бекон', 'пармезан', 'яйцо', 'черный перец'],
      ),
      Dish(
        name: 'Лосось на гриле',
        description: 'Филе лосося с овощами гриль и лимонным соусом',
        price: 750,
        emoji: '🐟',
        ingredients: [
          'лосось',
          'кабачки',
          'брокколи',
          'лимон',
          'оливковое масло'
        ],
      ),
    ],
  ),
  Category(
    name: 'Десерты',
    emoji: '🍰',
    color: Colors.pinkAccent,
    dishes: [
      Dish(
        name: 'Тирамису',
        description: 'Классический итальянский десерт с маскарпоне',
        price: 320,
        emoji: '🍰',
        ingredients: ['маскарпоне', 'савоярди', 'кофе', 'какао', 'яйца'],
      ),
      Dish(
        name: 'Чизкейк',
        description: 'Нежный чизкейк с ягодным соусом',
        price: 290,
        emoji: '🍰',
        ingredients: ['творожный сыр', 'печенье', 'сливки', 'ягоды', 'сахар'],
      ),
    ],
  ),
];

// ==================== ГЛОБАЛЬНАЯ КОРЗИНА ====================

List<Map<String, dynamic>> cart = [];

void addToCart(Dish dish, int quantity) {
  // Проверяем, есть ли уже такое блюдо в корзине
  final existingIndex = cart.indexWhere((item) => item['name'] == dish.name);
  if (existingIndex != -1) {
    // Увеличиваем количество
    cart[existingIndex]['quantity'] += quantity;
  } else {
    cart.add({
      'name': dish.name,
      'price': dish.price,
      'quantity': quantity,
      'emoji': dish.emoji,
    });
  }
}

// ==================== ГЛАВНОЕ ПРИЛОЖЕНИЕ ====================

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ресторан',
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
        useMaterial3: true,
      ),
      home: const CategoriesScreen(),
    );
  }
}

// ==================== ЭКРАН КАТЕГОРИЙ (С ПОИСКОМ) ====================

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchText = '';

  // Все блюда (плоский список) для поиска
  List<Dish> get _allDishes {
    return menuData.expand((category) => category.dishes).toList();
  }

  // Отфильтрованные блюда по поисковому запросу
  List<Dish> get _filteredDishes {
    if (_searchText.isEmpty) return [];
    return _allDishes.where((dish) {
      return dish.name.toLowerCase().contains(_searchText.toLowerCase()) ||
          dish.description.toLowerCase().contains(_searchText.toLowerCase());
    }).toList();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Меню'),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CartScreen()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Поле поиска (задание 3)
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Поиск блюд...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Colors.grey.shade100,
              ),
              onChanged: (value) {
                setState(() {
                  _searchText = value;
                });
              },
            ),
          ),
          // Основное содержимое
          Expanded(
            child: _searchText.isEmpty
                ? _buildCategoriesList()
                : _buildSearchResults(),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoriesList() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: menuData.length,
      itemBuilder: (context, index) {
        final category = menuData[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: category.color.withOpacity(0.2),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(12),
                    topRight: Radius.circular(12),
                  ),
                ),
                child: Row(
                  children: [
                    Text(category.emoji, style: const TextStyle(fontSize: 28)),
                    const SizedBox(width: 12),
                    Text(
                      category.name,
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              ...category.dishes.map((dish) => _buildDishTile(dish)),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSearchResults() {
    if (_filteredDishes.isEmpty) {
      return const Center(
        child: Text('Ничего не найдено'),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _filteredDishes.length,
      itemBuilder: (context, index) {
        final dish = _filteredDishes[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            leading: Text(dish.emoji, style: const TextStyle(fontSize: 30)),
            title: Text(dish.name),
            subtitle: Text('${dish.price} ₽'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => DishDetailScreen(dish: dish),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildDishTile(Dish dish) {
    return ListTile(
      leading: Text(dish.emoji, style: const TextStyle(fontSize: 28)),
      title: Text(dish.name),
      subtitle: Text('${dish.price} ₽'),
      trailing: const Icon(Icons.chevron_right),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => DishDetailScreen(dish: dish),
          ),
        );
      },
    );
  }
}

// ==================== ЭКРАН ДЕТАЛЕЙ БЛЮДА ====================

class DishDetailScreen extends StatefulWidget {
  final Dish dish;
  const DishDetailScreen({super.key, required this.dish});

  @override
  State<DishDetailScreen> createState() => _DishDetailScreenState();
}

class _DishDetailScreenState extends State<DishDetailScreen> {
  int _quantity = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.dish.name),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(widget.dish.emoji, style: const TextStyle(fontSize: 50)),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.dish.name,
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '${widget.dish.price} ₽',
                        style: TextStyle(
                          fontSize: 20,
                          color: Colors.grey.shade700,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 8),
            Text(
              widget.dish.description,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),
            const Text(
              'Ингредиенты:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: widget.dish.ingredients
                  .map((ing) => Chip(label: Text(ing)))
                  .toList(),
            ),
            const Spacer(),
            // Счетчик количества
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: const Icon(Icons.remove),
                  onPressed: () {
                    setState(() {
                      if (_quantity > 1) _quantity--;
                    });
                  },
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    '$_quantity',
                    style: const TextStyle(fontSize: 24),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: () {
                    setState(() {
                      _quantity++;
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Кнопка "В заказ"
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  addToCart(widget.dish, _quantity);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('${widget.dish.name} добавлено в корзину'),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                  Navigator.pop(context);
                },
                child: const Text('В заказ'),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

// ==================== ЭКРАН КОРЗИНЫ ====================

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  @override
  Widget build(BuildContext context) {
    // Подсчитываем общую сумму
    double total = 0;
    for (var item in cart) {
      total += item['price'] * item['quantity'];
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Корзина'),
        actions: [
          if (cart.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_sweep),
              onPressed: () {
                setState(() {
                  cart.clear();
                });
              },
              tooltip: 'Очистить корзину',
            ),
        ],
      ),
      body: cart.isEmpty
          ? const Center(
              child: Text('Корзина пуста'),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: cart.length,
                    itemBuilder: (context, index) {
                      final item = cart[index];
                      return ListTile(
                        leading: Text(item['emoji'],
                            style: const TextStyle(fontSize: 30)),
                        title: Text(item['name']),
                        subtitle:
                            Text('${item['price']} ₽ × ${item['quantity']}'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.remove),
                              onPressed: () {
                                setState(() {
                                  if (item['quantity'] > 1) {
                                    item['quantity']--;
                                  } else {
                                    cart.removeAt(index);
                                  }
                                });
                              },
                            ),
                            Text('${item['quantity']}'),
                            IconButton(
                              icon: const Icon(Icons.add),
                              onPressed: () {
                                setState(() {
                                  item['quantity']++;
                                });
                              },
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Итого:',
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '${total.toStringAsFixed(2)} ₽',
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}
