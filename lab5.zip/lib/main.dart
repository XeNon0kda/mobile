import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Мероприятия',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const EventsScreen(),
    );
  }
}

// Модель категории
class Category {
  final String name;
  final Color color;

  const Category(this.name, this.color);
}

// Предопределённые категории
final List<Category> categories = [
  Category('Концерт', Colors.red),
  Category('Спорт', Colors.green),
  Category('Лекция', Colors.blue),
  Category('Выставка', Colors.orange),
  Category('Кино', Colors.purple),
];

// Модель события
class Event {
  String title;
  String place;
  Category category;
  DateTime date;

  Event({
    required this.title,
    required this.place,
    required this.category,
    required this.date,
  });
}

// Глобальный список событий (начальные данные)
List<Event> events = [
  Event(
    title: 'Рок-концерт',
    place: 'Стадион',
    category: categories[0],
    date: DateTime(2025, 5, 15),
  ),
  Event(
    title: 'Футбольный матч',
    place: 'Арена',
    category: categories[1],
    date: DateTime(2025, 5, 20),
  ),
  Event(
    title: 'Лекция по Flutter',
    place: 'Онлайн',
    category: categories[2],
    date: DateTime(2025, 5, 10),
  ),
  Event(
    title: 'Выставка современного искусства',
    place: 'Музей',
    category: categories[3],
    date: DateTime(2025, 6, 1),
  ),
  Event(
    title: 'Премьера фильма',
    place: 'Кинотеатр',
    category: categories[4],
    date: DateTime(2025, 5, 25),
  ),
];

// Главный экран (сетка событий)
class EventsScreen extends StatefulWidget {
  const EventsScreen({super.key});

  @override
  State<EventsScreen> createState() => _EventsScreenState();
}

class _EventsScreenState extends State<EventsScreen> {
  String _searchQuery = '';
  bool _isSearching = false;
  final TextEditingController _searchController = TextEditingController();
  String _sortBy = 'date'; // 'date', 'title', 'category'

  // Отфильтрованные и отсортированные события
  List<Event> get filteredEvents {
    List<Event> filtered = events.where((event) {
      return event.title.toLowerCase().contains(_searchQuery.toLowerCase());
    }).toList();

    // Сортировка
    switch (_sortBy) {
      case 'title':
        filtered.sort((a, b) => a.title.compareTo(b.title));
        break;
      case 'category':
        filtered.sort((a, b) => a.category.name.compareTo(b.category.name));
        break;
      case 'date':
      default:
        filtered.sort((a, b) => a.date.compareTo(b.date));
        break;
    }
    return filtered;
  }

  void _toggleSearch() {
    setState(() {
      if (_isSearching) {
        _isSearching = false;
        _searchQuery = '';
        _searchController.clear();
      } else {
        _isSearching = true;
      }
    });
  }

  void _updateSearch(String query) {
    setState(() {
      _searchQuery = query;
    });
  }

  void _updateSort(String value) {
    setState(() {
      _sortBy = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: _isSearching
            ? TextField(
                controller: _searchController,
                autofocus: true,
                decoration: const InputDecoration(
                  hintText: 'Поиск по названию...',
                  border: InputBorder.none,
                ),
                onChanged: _updateSearch,
              )
            : const Text('Мероприятия'),
        actions: [
          // Кнопка поиска
          IconButton(
            icon: Icon(_isSearching ? Icons.close : Icons.search),
            onPressed: _toggleSearch,
          ),
          // Кнопка сортировки
          PopupMenuButton<String>(
            icon: const Icon(Icons.sort),
            onSelected: _updateSort,
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'date',
                child: Text('По дате'),
              ),
              const PopupMenuItem(
                value: 'title',
                child: Text('По названию'),
              ),
              const PopupMenuItem(
                value: 'category',
                child: Text('По категории'),
              ),
            ],
          ),
          // Кнопка статистики
          IconButton(
            icon: const Icon(Icons.pie_chart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const StatisticsScreen()),
              );
            },
          ),
        ],
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(8),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 1.2,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
        ),
        itemCount: filteredEvents.length,
        itemBuilder: (context, index) {
          final event = filteredEvents[index];
          return Card(
            color: event.category.color.withOpacity(0.2),
            child: InkWell(
              onTap: () => _openEventDetails(event),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      event.title,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const Spacer(),
                    Text(event.place),
                    const SizedBox(height: 4),
                    Text(
                      '${event.date.day}.${event.date.month}.${event.date.year}',
                      style: const TextStyle(fontSize: 12),
                    ),
                    Chip(
                      label: Text(event.category.name),
                      backgroundColor: event.category.color,
                      labelStyle: const TextStyle(color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _openEventDetails(Event event) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EventDetailsScreen(event: event),
      ),
    );
    if (result == true) {
      setState(() {}); // Обновить список после редактирования
    }
  }
}

// Экран деталей события
class EventDetailsScreen extends StatefulWidget {
  final Event event;
  const EventDetailsScreen({super.key, required this.event});

  @override
  State<EventDetailsScreen> createState() => _EventDetailsScreenState();
}

class _EventDetailsScreenState extends State<EventDetailsScreen> {
  late Event _event;

  @override
  void initState() {
    super.initState();
    _event = widget.event;
  }

  void _editEvent() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => EditEventBottomSheet(event: _event),
    ).then((edited) {
      if (edited == true) {
        setState(() {}); // обновить локально
        Navigator.pop(context, true); // вернуть на главный экран
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_event.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: _editEvent,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Название: ${_event.title}'),
            const SizedBox(height: 8),
            Text('Место: ${_event.place}'),
            const SizedBox(height: 8),
            Text('Категория: ${_event.category.name}'),
            const SizedBox(height: 8),
            Text(
                'Дата: ${_event.date.day}.${_event.date.month}.${_event.date.year}'),
          ],
        ),
      ),
    );
  }
}

// BottomSheet для редактирования
class EditEventBottomSheet extends StatefulWidget {
  final Event event;
  const EditEventBottomSheet({super.key, required this.event});

  @override
  State<EditEventBottomSheet> createState() => _EditEventBottomSheetState();
}

class _EditEventBottomSheetState extends State<EditEventBottomSheet> {
  late TextEditingController _titleController;
  late TextEditingController _placeController;
  late Category _selectedCategory;
  late DateTime _selectedDate;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.event.title);
    _placeController = TextEditingController(text: widget.event.place);
    _selectedCategory = widget.event.category;
    _selectedDate = widget.event.date;
  }

  @override
  void dispose() {
    _titleController.dispose();
    _placeController.dispose();
    super.dispose();
  }

  void _save() {
    setState(() {
      widget.event.title = _titleController.text;
      widget.event.place = _placeController.text;
      widget.event.category = _selectedCategory;
      widget.event.date = _selectedDate;
    });
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 16,
        right: 16,
        top: 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('Редактировать событие', style: TextStyle(fontSize: 20)),
          const SizedBox(height: 16),
          TextField(
            controller: _titleController,
            decoration: const InputDecoration(labelText: 'Название'),
          ),
          TextField(
            controller: _placeController,
            decoration: const InputDecoration(labelText: 'Место'),
          ),
          DropdownButtonFormField<Category>(
            value: _selectedCategory,
            items: categories.map((cat) {
              return DropdownMenuItem(
                value: cat,
                child: Text(cat.name),
              );
            }).toList(),
            onChanged: (value) {
              if (value != null) setState(() => _selectedCategory = value);
            },
            decoration: const InputDecoration(labelText: 'Категория'),
          ),
          ListTile(
            title: const Text('Дата'),
            subtitle: Text(
                '${_selectedDate.day}.${_selectedDate.month}.${_selectedDate.year}'),
            trailing: const Icon(Icons.calendar_today),
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: _selectedDate,
                firstDate: DateTime(2020),
                lastDate: DateTime(2030),
              );
              if (picked != null) setState(() => _selectedDate = picked);
            },
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _save,
            child: const Text('Сохранить'),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

// Экран статистики
class StatisticsScreen extends StatelessWidget {
  const StatisticsScreen({super.key});

  int get totalEvents => events.length;

  Event? get nextEvent {
    final now = DateTime.now();
    final future = events.where((e) => e.date.isAfter(now)).toList();
    future.sort((a, b) => a.date.compareTo(b.date));
    return future.isNotEmpty ? future.first : null;
  }

  List<Event> get upcomingEvents {
    final now = DateTime.now();
    final future = events.where((e) => e.date.isAfter(now)).toList();
    future.sort((a, b) => a.date.compareTo(b.date));
    return future.take(3).toList();
  }

  Map<Category, int> get categoryCounts {
    final Map<Category, int> counts = {};
    for (var cat in categories) {
      counts[cat] = events.where((e) => e.category == cat).length;
    }
    return counts;
  }

  @override
  Widget build(BuildContext context) {
    final counts = categoryCounts;
    final total = totalEvents;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Статистика'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Общая информация
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text('Всего событий: $total',
                        style: const TextStyle(fontSize: 18)),
                    const SizedBox(height: 8),
                    if (nextEvent != null)
                      Text(
                          'Ближайшее: ${nextEvent!.title} (${nextEvent!.date.day}.${nextEvent!.date.month})'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text('По категориям:',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            // Карточки категорий с прогрессом
            ...categories.map((cat) {
              final count = counts[cat] ?? 0;
              final percent = total > 0 ? count / total : 0.0;
              return Card(
                margin: const EdgeInsets.symmetric(vertical: 4),
                child: ListTile(
                  leading: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 48,
                        height: 48,
                        child: CircularProgressIndicator(
                          value: percent,
                          strokeWidth: 4,
                          color: cat.color,
                          backgroundColor: Colors.grey[200],
                        ),
                      ),
                      Text('$count',
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                  title: Text(cat.name),
                  subtitle: Text('${(percent * 100).toStringAsFixed(0)}%'),
                  trailing: Container(
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      color: cat.color,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              );
            }).toList(),
            const SizedBox(height: 24),
            const Text('Ближайшие события:',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            // Ближайшие 3 события с ExpansionTile
            ...upcomingEvents.map((event) {
              return ExpansionTile(
                title: Text(event.title),
                subtitle: Text(
                    '${event.date.day}.${event.date.month}.${event.date.year}'),
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Место: ${event.place}'),
                        Text('Категория: ${event.category.name}'),
                      ],
                    ),
                  ),
                ],
              );
            }).toList(),
          ],
        ),
      ),
    );
  }
}
