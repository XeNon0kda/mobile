import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// ==================== МОДЕЛЬ СОБЫТИЯ ====================

class Event {
  String name;
  String place;
  String category;
  DateTime date;

  Event({
    required this.name,
    required this.place,
    required this.category,
    required this.date,
  });
}

// ==================== НАЧАЛЬНЫЕ ДАННЫЕ ====================

final List<Event> initialEvents = [
  Event(
    name: 'Встреча с друзьями',
    place: 'Кафе "Уют"',
    category: 'Друзья',
    date: DateTime(2026, 3, 28),
  ),
  Event(
    name: 'Конференция Flutter',
    place: 'Онлайн',
    category: 'Работа',
    date: DateTime(2026, 4, 5),
  ),
  Event(
    name: 'День рождения',
    place: 'Ресторан "Прага"',
    category: 'Семья',
    date: DateTime(2026, 4, 10),
  ),
  Event(
    name: 'Спортзал',
    place: 'Фитнес-клуб',
    category: 'Спорт',
    date: DateTime(2026, 3, 29),
  ),
  Event(
    name: 'Врач',
    place: 'Поликлиника',
    category: 'Здоровье',
    date: DateTime(2026, 3, 30),
  ),
];

// ==================== ГЛАВНОЕ ПРИЛОЖЕНИЕ ====================

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Планировщик событий',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const MainScreen(),
    );
  }
}

// ==================== ГЛАВНЫЙ ЭКРАН ====================

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  List<Event> events = List.from(initialEvents);
  List<Event> filteredEvents = []; // события после фильтрации и сортировки
  String _searchQuery = '';
  String _sortBy = 'date'; // date, name, category
  bool _isSearching = false;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _applyFilters();
  }

  // Применяет поиск и сортировку
  void _applyFilters() {
    List<Event> result = List.from(events);

    // Фильтрация по поиску
    if (_searchQuery.isNotEmpty) {
      result = result
          .where((event) =>
              event.name.toLowerCase().contains(_searchQuery.toLowerCase()))
          .toList();
    }

    // Сортировка
    switch (_sortBy) {
      case 'date':
        result.sort((a, b) => a.date.compareTo(b.date));
        break;
      case 'name':
        result.sort((a, b) => a.name.compareTo(b.name));
        break;
      case 'category':
        result.sort((a, b) => a.category.compareTo(b.category));
        break;
    }

    setState(() {
      filteredEvents = result;
    });
  }

  // Вызывается после изменения списка событий
  void _onEventsChanged() {
    _applyFilters();
  }

  // Редактирование события
  void _editEvent(Event event, int index) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => EditEventSheet(
        event: event,
        onSave: (updatedEvent) {
          setState(() {
            events[index] = updatedEvent;
          });
          _onEventsChanged();
          Navigator.pop(context);
        },
      ),
    );
  }

  // Открыть статистику
  void _openStatistics() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StatisticsScreen(events: events),
      ),
    ).then((_) => _onEventsChanged()); // обновляем на случай изменений
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: filteredEvents.isEmpty
          ? const Center(child: Text('Нет событий'))
          : GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.2,
              ),
              itemCount: filteredEvents.length,
              itemBuilder: (context, index) {
                final event = filteredEvents[index];
                final originalIndex = events.indexOf(event);
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => EventDetailScreen(
                          event: event,
                          onEdit: () => _editEvent(event, originalIndex),
                        ),
                      ),
                    ).then((_) => _onEventsChanged());
                  },
                  child: Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            event.name,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Icon(Icons.place, size: 16),
                              const SizedBox(width: 4),
                              Expanded(
                                child: Text(
                                  event.place,
                                  style: const TextStyle(fontSize: 12),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const Icon(Icons.category, size: 16),
                              const SizedBox(width: 4),
                              Text(
                                event.category,
                                style: const TextStyle(fontSize: 12),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const Icon(Icons.calendar_today, size: 16),
                              const SizedBox(width: 4),
                              Text(
                                '${event.date.day}.${event.date.month}.${event.date.year}',
                                style: const TextStyle(fontSize: 12),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    if (_isSearching) {
      return AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            setState(() {
              _isSearching = false;
              _searchQuery = '';
              _searchController.clear();
              _applyFilters();
            });
          },
        ),
        title: TextField(
          controller: _searchController,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'Поиск...',
            border: InputBorder.none,
          ),
          onChanged: (value) {
            setState(() {
              _searchQuery = value;
            });
            _applyFilters();
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.clear),
            onPressed: () {
              _searchController.clear();
              setState(() {
                _searchQuery = '';
              });
              _applyFilters();
            },
          ),
        ],
      );
    } else {
      return AppBar(
        title: const Text('События'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.sort),
            onSelected: (value) {
              setState(() {
                _sortBy = value;
              });
              _applyFilters();
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'date',
                child: Text('По дате'),
              ),
              const PopupMenuItem(
                value: 'name',
                child: Text('По названию'),
              ),
              const PopupMenuItem(
                value: 'category',
                child: Text('По категории'),
              ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              setState(() {
                _isSearching = true;
              });
            },
          ),
          IconButton(
            icon: const Icon(Icons.pie_chart),
            onPressed: _openStatistics,
          ),
        ],
      );
    }
  }
}

// ==================== ЭКРАН ДЕТАЛЕЙ ====================

class EventDetailScreen extends StatelessWidget {
  final Event event;
  final VoidCallback onEdit;

  const EventDetailScreen(
      {super.key, required this.event, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(event.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              Navigator.pop(context);
              onEdit();
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Название',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            Text(event.name, style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 16),
            const Text(
              'Место',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            Text(event.place, style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            const Text(
              'Категория',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            Text(event.category, style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            const Text(
              'Дата',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            Text(
              '${event.date.day}.${event.date.month}.${event.date.year}',
              style: const TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== BOTTOM SHEET ДЛЯ РЕДАКТИРОВАНИЯ ====================

class EditEventSheet extends StatefulWidget {
  final Event event;
  final Function(Event) onSave;

  const EditEventSheet({super.key, required this.event, required this.onSave});

  @override
  State<EditEventSheet> createState() => _EditEventSheetState();
}

class _EditEventSheetState extends State<EditEventSheet> {
  late TextEditingController _nameController;
  late TextEditingController _placeController;
  late TextEditingController _categoryController;
  late DateTime _selectedDate;

  final List<String> _categories = [
    'Друзья',
    'Работа',
    'Семья',
    'Спорт',
    'Здоровье',
    'Другое'
  ];

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.event.name);
    _placeController = TextEditingController(text: widget.event.place);
    _categoryController = TextEditingController(text: widget.event.category);
    _selectedDate = widget.event.date;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _placeController.dispose();
    _categoryController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 16,
        right: 16,
        top: 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Редактировать событие',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Название',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _placeController,
              decoration: const InputDecoration(
                labelText: 'Место',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _categoryController.text,
              decoration: const InputDecoration(
                labelText: 'Категория',
                border: OutlineInputBorder(),
              ),
              items: _categories.map((cat) {
                return DropdownMenuItem(value: cat, child: Text(cat));
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _categoryController.text = value!;
                });
              },
            ),
            const SizedBox(height: 16),
            ListTile(
              title: const Text('Дата'),
              subtitle: Text(
                '${_selectedDate.day}.${_selectedDate.month}.${_selectedDate.year}',
              ),
              trailing: const Icon(Icons.calendar_today),
              onTap: () => _selectDate(context),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                final updatedEvent = Event(
                  name: _nameController.text,
                  place: _placeController.text,
                  category: _categoryController.text,
                  date: _selectedDate,
                );
                widget.onSave(updatedEvent);
              },
              child: const Text('Сохранить'),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

// ==================== ЭКРАН СТАТИСТИКИ ====================

class StatisticsScreen extends StatelessWidget {
  final List<Event> events;

  const StatisticsScreen({super.key, required this.events});

  // Группировка по категориям
  Map<String, int> _getCategoryCounts() {
    final Map<String, int> counts = {};
    for (var event in events) {
      counts[event.category] = (counts[event.category] ?? 0) + 1;
    }
    return counts;
  }

  // Цвета для категорий
  Color _getCategoryColor(String category) {
    switch (category) {
      case 'Друзья':
        return Colors.blue;
      case 'Работа':
        return Colors.green;
      case 'Семья':
        return Colors.orange;
      case 'Спорт':
        return Colors.red;
      case 'Здоровье':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }

  // Ближайшие три события
  List<Event> _getNextEvents() {
    final now = DateTime.now();
    final futureEvents = events.where((e) => e.date.isAfter(now)).toList();
    futureEvents.sort((a, b) => a.date.compareTo(b.date));
    return futureEvents.take(3).toList();
  }

  @override
  Widget build(BuildContext context) {
    final total = events.length;
    final categoryCounts = _getCategoryCounts();
    final nextEvents = _getNextEvents();
    final nearestEvent = nextEvents.isNotEmpty ? nextEvents.first : null;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Статистика'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Общая информация
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(
                      'Всего событий: $total',
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    if (nearestEvent != null)
                      Text(
                        'Ближайшее: ${nearestEvent.name} (${nearestEvent.date.day}.${nearestEvent.date.month}.${nearestEvent.date.year})',
                        style: const TextStyle(fontSize: 16),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Статистика по категориям',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            // Карточки категорий
            ...categoryCounts.entries.map((entry) {
              final category = entry.key;
              final count = entry.value;
              final percentage = total == 0 ? 0.0 : count / total;
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      // CircularProgressIndicator
                      SizedBox(
                        width: 60,
                        height: 60,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            CircularProgressIndicator(
                              value: percentage,
                              strokeWidth: 6,
                              color: _getCategoryColor(category),
                              backgroundColor: Colors.grey[200],
                            ),
                            Text(
                              '$count',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              category,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '${(percentage * 100).toStringAsFixed(1)}% событий',
                              style: const TextStyle(
                                  fontSize: 14, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
            const SizedBox(height: 20),
            const Text(
              'Ближайшие события',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            if (nextEvents.isEmpty)
              const Center(child: Text('Нет предстоящих событий'))
            else
              ...nextEvents.map((event) {
                return ExpansionTile(
                  title: Text(event.name),
                  subtitle: Text(
                    '${event.date.day}.${event.date.month}.${event.date.year}',
                  ),
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Место: ${event.place}'),
                          const SizedBox(height: 4),
                          Text('Категория: ${event.category}'),
                        ],
                      ),
                    ),
                  ],
                );
              }),
          ],
        ),
      ),
    );
  }
}
