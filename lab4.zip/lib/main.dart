import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// ==================== МОДЕЛИ ДАННЫХ ====================

class Exercise {
  final String name;
  final int calories;
  final int sets;
  final int durationSeconds;

  const Exercise({
    required this.name,
    required this.calories,
    this.sets = 3,
    this.durationSeconds = 30,
  });
}

// ==================== НАЧАЛЬНЫЕ ДАННЫЕ ====================

// Используем final, не const, так как конструктор Exercise не const
final List<Exercise> defaultExercises = [
  const Exercise(name: 'Приседания', calories: 50, sets: 3),
  const Exercise(name: 'Отжимания', calories: 40, sets: 3),
  const Exercise(name: 'Планка', calories: 30, sets: 3, durationSeconds: 60),
  const Exercise(name: 'Бёрпи', calories: 60, sets: 3),
];

// ==================== ГЛАВНЫЙ ЭКРАН С ВКЛАДКАМИ ====================

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Фитнес-трекер',
      theme: ThemeData(
        primarySwatch: Colors.green,
        useMaterial3: true,
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  // Список упражнений на сегодня
  List<Exercise> todayWorkout = List.from(defaultExercises);

  // История тренировок
  List<Map<String, dynamic>> history = [];

  // Метод удаления упражнения
  void _removeExercise(int index) {
    setState(() {
      todayWorkout.removeAt(index);
    });
  }

  // Метод завершения дня: сохраняет текущую тренировку в историю и сбрасывает
  void _completeDay() {
    if (todayWorkout.isEmpty) return;

    final totalCalories = todayWorkout.fold(0, (sum, e) => sum + e.calories);
    final doneCount = todayWorkout.length;

    history.add({
      'date': DateTime.now().toString().substring(0, 10),
      'exercises': doneCount,
      'calories': totalCalories,
      'details': List.from(todayWorkout),
    });

    setState(() {
      todayWorkout = List.from(defaultExercises);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: [
          WorkoutScreen(
            exercises: todayWorkout,
            onRemove: _removeExercise,
            onCompleteDay: _completeDay,
          ),
          ProgressScreen(exercises: todayWorkout),
          const SettingsScreen(),
          HistoryScreen(history: history),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.fitness_center),
            label: 'Тренировка',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Прогресс',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Настройки',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'История',
          ),
        ],
      ),
    );
  }
}

// ==================== ВКЛАДКА «ТРЕНИРОВКА» ====================

class WorkoutScreen extends StatelessWidget {
  final List<Exercise> exercises;
  final Function(int) onRemove;
  final VoidCallback onCompleteDay;

  const WorkoutScreen({
    super.key,
    required this.exercises,
    required this.onRemove,
    required this.onCompleteDay,
  });

  void _showDeleteDialog(BuildContext context, int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Удалить упражнение'),
        content:
            Text('Вы уверены, что хотите удалить "${exercises[index].name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Отмена'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              onRemove(index);
            },
            child: const Text('Удалить'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Тренировка на сегодня'),
        actions: [
          IconButton(
            icon: const Icon(Icons.check_circle),
            onPressed: onCompleteDay,
            tooltip: 'Завершить день',
          ),
        ],
      ),
      body: exercises.isEmpty
          ? const Center(child: Text('Все упражнения выполнены!'))
          : ListView.builder(
              itemCount: exercises.length,
              itemBuilder: (context, index) {
                final exercise = exercises[index];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    leading: CircleAvatar(
                      child: Text('${exercise.calories}'),
                    ),
                    title: Text(exercise.name),
                    subtitle: Text(
                        '${exercise.sets} подхода • ${exercise.durationSeconds} сек'),
                    trailing: const Icon(Icons.timer),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => TimerScreen(exercise: exercise),
                        ),
                      );
                    },
                    onLongPress: () => _showDeleteDialog(context, index),
                  ),
                );
              },
            ),
    );
  }
}

// ==================== ВКЛАДКА «ПРОГРЕСС» ====================

class ProgressScreen extends StatelessWidget {
  final List<Exercise> exercises;

  const ProgressScreen({super.key, required this.exercises});

  @override
  Widget build(BuildContext context) {
    final totalCalories = exercises.fold(0, (sum, e) => sum + e.calories);
    final totalExercises = exercises.length;
    // Переменная completed была неиспользуемой – удалена

    return Scaffold(
      appBar: AppBar(
        title: const Text('Прогресс сегодня'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Card(
              margin: const EdgeInsets.all(16),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const Text(
                      'Текущая тренировка',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Упражнений: $totalExercises',
                      style: const TextStyle(fontSize: 18),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Сожжено калорий: $totalCalories',
                      style: const TextStyle(fontSize: 18),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== ВКЛАДКА «НАСТРОЙКИ» ====================

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Настройки'),
      ),
      body: const Center(
        child: Text('Здесь будут настройки приложения'),
      ),
    );
  }
}

// ==================== ВКЛАДКА «ИСТОРИЯ» ====================

class HistoryScreen extends StatelessWidget {
  final List<Map<String, dynamic>> history;

  const HistoryScreen({super.key, required this.history});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('История тренировок'),
      ),
      body: history.isEmpty
          ? const Center(child: Text('Пока нет сохранённых тренировок'))
          : ListView.builder(
              itemCount: history.length,
              itemBuilder: (context, index) {
                final record = history[index];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    leading: const Icon(Icons.calendar_today),
                    title: Text(record['date']),
                    subtitle: Text(
                      'Упражнений: ${record['exercises']} • Калорий: ${record['calories']}',
                    ),
                    isThreeLine: false,
                  ),
                );
              },
            ),
    );
  }
}

// ==================== ЭКРАН ТАЙМЕРА ====================

class TimerScreen extends StatefulWidget {
  final Exercise exercise;

  const TimerScreen({super.key, required this.exercise});

  @override
  State<TimerScreen> createState() => _TimerScreenState();
}

class _TimerScreenState extends State<TimerScreen> {
  late int _remainingSeconds;
  bool _isRunning = false;
  int _currentSet = 1;
  late int _totalSets;

  @override
  void initState() {
    super.initState();
    _totalSets = widget.exercise.sets;
    _remainingSeconds = widget.exercise.durationSeconds;
  }

  void _startTimer() {
    if (_isRunning) return;
    _isRunning = true;
    _runTimer();
  }

  void _runTimer() async {
    while (_isRunning && _remainingSeconds > 0) {
      await Future.delayed(const Duration(seconds: 1));
      if (mounted && _isRunning) {
        setState(() {
          if (_remainingSeconds > 0) _remainingSeconds--;
        });
      }
    }
    if (_remainingSeconds == 0 && mounted) {
      _isRunning = false;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Подход завершён!')),
      );
      if (_currentSet < _totalSets) {
        _showNextSetDialog();
      } else {
        _showAllSetsCompletedDialog();
      }
    }
  }

  void _showNextSetDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Подход завершён'),
        content: Text(
            'Перейти к следующему подходу (${_currentSet + 1}/$_totalSets)?'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('Позже'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _currentSet++;
                _remainingSeconds = widget.exercise.durationSeconds;
                _isRunning = false;
              });
            },
            child: const Text('Следующий'),
          ),
        ],
      ),
    );
  }

  void _showAllSetsCompletedDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Поздравляем!'),
        content: Text(
            'Вы выполнили все $_totalSets подходов "${widget.exercise.name}".'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Закрыть'),
          ),
        ],
      ),
    );
  }

  void _pauseTimer() {
    setState(() {
      _isRunning = false;
    });
  }

  void _resetTimer() {
    setState(() {
      _isRunning = false;
      _remainingSeconds = widget.exercise.durationSeconds;
      _currentSet = 1;
    });
  }

  @override
  void dispose() {
    _isRunning = false;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final minutes = _remainingSeconds ~/ 60;
    final seconds = _remainingSeconds % 60;
    final timeString =
        '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.exercise.name),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              widget.exercise.name,
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Text(
              'Подход $_currentSet из $_totalSets',
              style: const TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 40),
            Text(
              timeString,
              style: const TextStyle(fontSize: 72, fontFamily: 'monospace'),
            ),
            const SizedBox(height: 40),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: _startTimer,
                  child: const Text('Старт'),
                ),
                const SizedBox(width: 20),
                ElevatedButton(
                  onPressed: _pauseTimer,
                  child: const Text('Пауза'),
                ),
                const SizedBox(width: 20),
                ElevatedButton(
                  onPressed: _resetTimer,
                  child: const Text('Сброс'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
