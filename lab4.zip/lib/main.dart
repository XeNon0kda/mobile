import 'dart:async';
import 'package:flutter/material.dart';

void main() {
  runApp(const FitnessApp());
}

class FitnessApp extends StatelessWidget {
  const FitnessApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Фитнес-трекер',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      home: const MainScreen(),
    );
  }
}

// Модель упражнения
class Exercise {
  final String name;
  final int sets;
  final int calories;
  bool isCompleted;

  Exercise({
    required this.name,
    required this.sets,
    required this.calories,
    this.isCompleted = false,
  });

  // Копирование для сброса состояния
  Exercise copy() => Exercise(
        name: name,
        sets: sets,
        calories: calories,
        isCompleted: isCompleted,
      );
}

// Начальные данные упражнений
List<Exercise> initialExercises = [
  Exercise(name: 'Отжимания', sets: 3, calories: 50),
  Exercise(name: 'Приседания', sets: 3, calories: 40),
  Exercise(name: 'Планка', sets: 3, calories: 30),
  Exercise(name: 'Бёрпи', sets: 3, calories: 60),
  Exercise(name: 'Выпады', sets: 3, calories: 35),
];

// Глобальный список упражнений (текущий)
List<Exercise> exercises = [];

// Глобальная история тренировок
List<Map<String, dynamic>> history = [];

// Главный экран с вкладками
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    // Инициализация списка упражнений копией начальных данных
    exercises = initialExercises.map((e) => e.copy()).toList();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // Метод для обновления интерфейса после изменений в упражнениях
  void refresh() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Фитнес-трекер'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.fitness_center), text: 'Тренировка'),
            Tab(icon: Icon(Icons.show_chart), text: 'Прогресс'),
            Tab(icon: Icon(Icons.history), text: 'История'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          WorkoutScreen(onRefresh: refresh),
          ProgressScreen(),
          HistoryScreen(),
        ],
      ),
    );
  }
}

// Вкладка "Тренировка"
class WorkoutScreen extends StatefulWidget {
  final VoidCallback onRefresh;
  const WorkoutScreen({super.key, required this.onRefresh});

  @override
  State<WorkoutScreen> createState() => _WorkoutScreenState();
}

class _WorkoutScreenState extends State<WorkoutScreen> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            itemCount: exercises.length,
            itemBuilder: (context, index) {
              final exercise = exercises[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: ListTile(
                  leading: Checkbox(
                    value: exercise.isCompleted,
                    onChanged: (value) {
                      setState(() {
                        exercise.isCompleted = value ?? false;
                      });
                      widget.onRefresh(); // обновляем прогресс
                    },
                  ),
                  title: Text(exercise.name),
                  subtitle: Text(
                      '${exercise.sets} подхода • ${exercise.calories} ккал'),
                  trailing: const Icon(Icons.timer),
                  onTap: () {
                    // Задание 3: открыть таймер
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => TimerScreen(exercise: exercise),
                      ),
                    ).then((_) {
                      // При возвращении с таймера обновляем, если нужно
                      widget.onRefresh();
                    });
                  },
                  onLongPress: () {
                    // Задание 1: удаление упражнения
                    _showDeleteDialog(index);
                  },
                ),
              );
            },
          ),
        ),
        // Кнопка завершения дня
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: ElevatedButton.icon(
            onPressed: _finishDay,
            icon: const Icon(Icons.save),
            label: const Text('Завершить день'),
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 48),
            ),
          ),
        ),
      ],
    );
  }

  void _showDeleteDialog(int index) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить упражнение'),
        content: Text('Удалить "${exercises[index].name}" из списка?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Отмена'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                exercises.removeAt(index);
              });
              widget.onRefresh(); // обновляем прогресс
              Navigator.pop(ctx);
            },
            child: const Text('Удалить'),
          ),
        ],
      ),
    );
  }

  void _finishDay() {
    // Подсчёт выполненных упражнений и калорий
    int doneCount = exercises.where((e) => e.isCompleted).length;
    int totalCalories = exercises
        .where((e) => e.isCompleted)
        .fold(0, (sum, e) => sum + e.calories);

    // Сохраняем в историю
    history.add({
      'date': DateTime.now().toString().substring(0, 10),
      'exercises': doneCount,
      'calories': totalCalories,
    });

    // Сбрасываем список на начальные данные
    setState(() {
      exercises = initialExercises.map((e) => e.copy()).toList();
    });
    widget.onRefresh();

    // Показываем уведомление
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Тренировка сохранена!')),
    );
  }
}

// Вкладка "Прогресс"
class ProgressScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    int completed = exercises.where((e) => e.isCompleted).length;
    int totalCalories = exercises
        .where((e) => e.isCompleted)
        .fold(0, (sum, e) => sum + e.calories);

    return Center(
      child: Card(
        margin: const EdgeInsets.all(24),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Прогресс сегодня',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 24),
              Text(
                'Выполнено упражнений: $completed из ${exercises.length}',
                style: const TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 12),
              Text(
                'Сожжено калорий: $totalCalories ккал',
                style: const TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 24),
              LinearProgressIndicator(
                value: exercises.isEmpty ? 0 : completed / exercises.length,
                minHeight: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Вкладка "История"
class HistoryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    if (history.isEmpty) {
      return const Center(
        child: Text(
            'История пуста. Завершите тренировку, чтобы сохранить данные.'),
      );
    }

    return ListView.builder(
      itemCount: history.length,
      itemBuilder: (context, index) {
        final day = history[index];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: ListTile(
            leading: const Icon(Icons.calendar_today),
            title: Text(day['date']),
            subtitle: Text(
                'Упражнений: ${day['exercises']} • Калорий: ${day['calories']}'),
          ),
        );
      },
    );
  }
}

// Экран таймера (Задание 3)
class TimerScreen extends StatefulWidget {
  final Exercise exercise;
  const TimerScreen({super.key, required this.exercise});

  @override
  State<TimerScreen> createState() => _TimerScreenState();
}

class _TimerScreenState extends State<TimerScreen> {
  late int _secondsLeft;
  Timer? _timer;
  bool _isRunning = false;

  @override
  void initState() {
    super.initState();
    _secondsLeft = 30; // таймер 30 секунд
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startTimer() {
    if (_isRunning) return;
    _isRunning = true;
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_secondsLeft > 0) {
          _secondsLeft--;
        } else {
          _stopTimer();
          // Уведомление о завершении подхода
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Подход завершён!')),
          );
        }
      });
    });
  }

  void _pauseTimer() {
    _timer?.cancel();
    _isRunning = false;
  }

  void _resetTimer() {
    _timer?.cancel();
    setState(() {
      _secondsLeft = 30;
      _isRunning = false;
    });
  }

  void _stopTimer() {
    _timer?.cancel();
    _isRunning = false;
  }

  String _formatTime(int seconds) {
    int minutes = seconds ~/ 60;
    int secs = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.exercise.name),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              widget.exercise.name,
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Text(
              'Подходов: ${widget.exercise.sets}',
              style: const TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 32),
            Text(
              _formatTime(_secondsLeft),
              style: const TextStyle(fontSize: 64, fontFamily: 'monospace'),
            ),
            const SizedBox(height: 48),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  onPressed: _startTimer,
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('Старт'),
                ),
                const SizedBox(width: 16),
                ElevatedButton.icon(
                  onPressed: _pauseTimer,
                  icon: const Icon(Icons.pause),
                  label: const Text('Пауза'),
                ),
                const SizedBox(width: 16),
                ElevatedButton.icon(
                  onPressed: _resetTimer,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Сброс'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
