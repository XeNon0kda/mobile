import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// MyApp — StatefulWidget для управления темой
class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _isDark = false; // флаг темы

  // Функция переключения темы
  void _toggleTheme() {
    setState(() {
      _isDark = !_isDark;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Мой профиль',
      theme: _isDark
          ? ThemeData.dark()
          : ThemeData.light().copyWith(
              // базовый цвет приложения (используется в AppBar, кнопках и т.д.)
              colorScheme: ColorScheme.fromSeed(
                seedColor: Colors.deepPurple, // изменённый цвет (задание 1)
                brightness: Brightness.light,
              ),
              useMaterial3: true,
            ),
      darkTheme: ThemeData.dark().copyWith(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      themeMode: _isDark ? ThemeMode.dark : ThemeMode.light,
      home: MainScreen(onToggleTheme: _toggleTheme),
    );
  }
}

// Главный экран с BottomNavigationBar
class MainScreen extends StatefulWidget {
  final VoidCallback onToggleTheme;

  const MainScreen({super.key, required this.onToggleTheme});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [];

  @override
  void initState() {
    super.initState();
    // Инициализируем экраны, передавая функцию переключения темы в ProfileScreen
    _screens.addAll([
      ProfileScreen(onToggleTheme: widget.onToggleTheme),
      const GalleryScreen(),
      const ContactsScreen(),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Профиль',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.photo_library),
            label: 'Галерея',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.contacts),
            label: 'Контакты',
          ),
        ],
      ),
    );
  }
}

// Экран профиля
class ProfileScreen extends StatelessWidget {
  final VoidCallback? onToggleTheme;

  const ProfileScreen({super.key, this.onToggleTheme});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Профиль'),
        actions: [
          // Кнопка переключения темы (задание 2)
          IconButton(
            icon: const Icon(Icons.brightness_6),
            onPressed: onToggleTheme,
            tooltip: 'Сменить тему',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Аватар
            const CircleAvatar(
              radius: 60,
              backgroundImage: NetworkImage(
                  'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'),
            ),
            const SizedBox(height: 16),
            // Имя
            Text(
              'Алексей Иванов', // замените на своё имя
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            // Контактная информация
            Card(
              child: ListTile(
                leading: const Icon(Icons.email),
                title: const Text('Email'),
                subtitle: const Text('alexey.ivanov@example.com'),
                onTap: () {},
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.phone),
                title: const Text('Телефон'),
                subtitle: const Text('+7 (999) 123-45-67'),
                onTap: () {},
              ),
            ),
            // Интересы (задание 1)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Интересы',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    const Wrap(
                      spacing: 8,
                      children: [
                        Chip(label: Text('Flutter')),
                        Chip(label: Text('Dart')),
                        Chip(label: Text('Фотография')),
                        Chip(label: Text('Путешествия')),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            // Дополнительная карточка (Университет) — задание 1
            Card(
              child: ListTile(
                leading: const Icon(Icons.school),
                title: const Text('Университет'),
                subtitle: const Text('МГУ им. М.В. Ломоносова, факультет ВМК'),
                onTap: () {},
              ),
            ),
            // Дополнительная карточка (GitHub) — тоже можно добавить, но условие требует одну
            // Можно оставить как ещё одну для примера
            Card(
              child: ListTile(
                leading: const Icon(Icons.code),
                title: const Text('GitHub'),
                subtitle: const Text('github.com/alexeyivanov'),
                onTap: () {},
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Экран галереи (задание 3)
class GalleryScreen extends StatelessWidget {
  const GalleryScreen({super.key});

  // Список URL изображений
  final List<String> imageUrls = const [
    'https://images.unsplash.com/photo-1500462918059-b1a0cb512f1d?w=300',
    'https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=300',
    'https://images.unsplash.com/photo-1536240476400-738af1bd2c6b?w=300',
    'https://images.unsplash.com/photo-1485846234645-a62644f84728?w=300',
    'https://images.unsplash.com/photo-1495465798138-718f86d1a4bc?w=300',
    'https://images.unsplash.com/photo-1523800503107-5bc3ba2a6f81?w=300',
    'https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=300',
    'https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=300',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Галерея'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        childAspectRatio: 1,
        padding: const EdgeInsets.all(8),
        children: imageUrls.map((url) {
          return Card(
            clipBehavior: Clip.antiAlias,
            child: Image.network(
              url,
              fit: BoxFit.cover,
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) return child;
                return const Center(child: CircularProgressIndicator());
              },
              errorBuilder: (context, error, stackTrace) {
                return const Center(child: Icon(Icons.broken_image));
              },
            ),
          );
        }).toList(),
      ),
    );
  }
}

// Экран контактов (задание 3)
class ContactsScreen extends StatelessWidget {
  const ContactsScreen({super.key});

  // Модель контакта
  final List<Map<String, String>> contacts = const [
    {
      'name': 'Анна Смирнова',
      'phone': '+7 (901) 234-56-78',
      'email': 'anna@example.com'
    },
    {
      'name': 'Иван Петров',
      'phone': '+7 (902) 345-67-89',
      'email': 'ivan@example.com'
    },
    {
      'name': 'Мария Кузнецова',
      'phone': '+7 (903) 456-78-90',
      'email': 'maria@example.com'
    },
    {
      'name': 'Дмитрий Соколов',
      'phone': '+7 (904) 567-89-01',
      'email': 'dmitry@example.com'
    },
    {
      'name': 'Елена Попова',
      'phone': '+7 (905) 678-90-12',
      'email': 'elena@example.com'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Контакты'),
      ),
      body: ListView.builder(
        itemCount: contacts.length,
        itemBuilder: (context, index) {
          final contact = contacts[index];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: ListTile(
              leading: CircleAvatar(
                child: Text(contact['name']![0]),
              ),
              title: Text(contact['name']!),
              subtitle: Text('${contact['phone']}  •  ${contact['email']}'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                // Можно показать диалог с деталями
                showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: Text(contact['name']!),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Телефон: ${contact['phone']}'),
                        Text('Email: ${contact['email']}'),
                      ],
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text('Закрыть'),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
