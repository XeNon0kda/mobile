import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// ==================== MyApp (управление темой) ====================
class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _isDark = false; // текущая тема: false – светлая, true – тёмная

  void _toggleTheme() {
    setState(() {
      _isDark = !_isDark;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Мой профиль',
      theme: _isDark
          ? ThemeData.dark()
          : ThemeData(
              brightness: Brightness.light,
              primarySwatch: Colors.teal, // задание 1: меняем цвет на teal
              useMaterial3: true,
            ),
      home: MainScreen(onToggleTheme: _toggleTheme),
    );
  }
}

// ==================== Главный экран с вкладками (задание 3) ====================
class MainScreen extends StatefulWidget {
  final VoidCallback onToggleTheme;
  const MainScreen({super.key, required this.onToggleTheme});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  // Список экранов для вкладок
  late final List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      ProfileScreen(onToggleTheme: widget.onToggleTheme),
      const GalleryScreen(),
      const ContactsScreen(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Профиль',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.photo_library),
            label: 'Галерея',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.contacts),
            label: 'Контакты',
          ),
        ],
      ),
    );
  }
}

// ==================== Экран профиля (задания 1 и 2) ====================
class ProfileScreen extends StatefulWidget {
  final VoidCallback onToggleTheme;
  const ProfileScreen({super.key, required this.onToggleTheme});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // Данные профиля (задание 1)
  final String name = 'Иван Петров';
  final String contacts = 'ivan@example.com | +7 (999) 123-45-67';
  final String interests = 'Flutter, программирование, фотография, путешествия';
  final String university =
      'Московский государственный университет'; // дополнительная карточка

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Мой профиль'),
        actions: [
          // Кнопка переключения темы (задание 2)
          IconButton(
            icon: const Icon(Icons.brightness_6),
            onPressed: widget.onToggleTheme,
            tooltip: 'Сменить тему',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Карточка "О себе"
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'О себе',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    Text('Имя: $name'),
                    const SizedBox(height: 8),
                    Text('Контакты: $contacts'),
                    const SizedBox(height: 8),
                    Text('Интересы: $interests'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Дополнительная карточка "Университет" (задание 1)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Университет',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    Text(university),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== Экран галереи (задание 3) ====================
class GalleryScreen extends StatelessWidget {
  const GalleryScreen({super.key});

  // Список URL изображений (можно заменить на любые)
  final List<String> imageUrls = const [
    'https://picsum.photos/id/1015/300/200', // пейзаж
    'https://picsum.photos/id/104/300/200', // собака
    'https://picsum.photos/id/106/300/200', // цветы
    'https://picsum.photos/id/107/300/200', // трава
    'https://picsum.photos/id/10/300/200', // туман
    'https://picsum.photos/id/100/300/200', // камера
    'https://picsum.photos/id/102/300/200', // озеро
    'https://picsum.photos/id/108/300/200', // пшеница
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Галерея'),
      ),
      body: GridView.count(
        crossAxisCount: 2, // 2 колонки
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        padding: const EdgeInsets.all(8.0),
        children: imageUrls.map((url) {
          return ClipRRect(
            borderRadius: BorderRadius.circular(8.0),
            child: Image.network(
              url,
              fit: BoxFit.cover,
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) return child;
                return const Center(child: CircularProgressIndicator());
              },
              errorBuilder: (context, error, stackTrace) =>
                  const Center(child: Icon(Icons.broken_image, size: 50)),
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ==================== Экран контактов (задание 3) ====================
class ContactsScreen extends StatelessWidget {
  const ContactsScreen({super.key});

  // Данные контактов
  final List<Map<String, String>> contacts = const [
    {
      'name': 'Анна Смирнова',
      'phone': '+7 (901) 234-56-78',
      'email': 'anna@example.com'
    },
    {
      'name': 'Петр Иванов',
      'phone': '+7 (902) 345-67-89',
      'email': 'petr@example.com'
    },
    {
      'name': 'Мария Кузнецова',
      'phone': '+7 (903) 456-78-90',
      'email': 'maria@example.com'
    },
    {
      'name': 'Дмитрий Соколов',
      'phone': '+7 (904) 567-89-01',
      'email': 'dmitry@example.com'
    },
    {
      'name': 'Елена Васильева',
      'phone': '+7 (905) 678-90-12',
      'email': 'elena@example.com'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Контакты'),
      ),
      body: ListView.builder(
        itemCount: contacts.length,
        itemBuilder: (context, index) {
          final contact = contacts[index];
          return ListTile(
            leading: CircleAvatar(
              child: Text(contact['name']![0]), // первая буква имени
            ),
            title: Text(contact['name']!),
            subtitle: Text('${contact['phone']} | ${contact['email']}'),
            isThreeLine: true,
            trailing: const Icon(Icons.message),
          );
        },
      ),
    );
  }
}
